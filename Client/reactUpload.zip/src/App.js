import React, { Component } from 'react';
import Dropzone from 'react-dropzone';
import csv from 'csv';

class App extends Component {
  constructor(props) {
    super(props);
}
  componentDidMount(){

  }
  onDrop(files) {

    this.setState({ files });

    var file = files[0];

    const reader = new FileReader();
    reader.onload = () => {
      csv.parse(reader.result, (err, data) => {

        var requests = [];

        for (var i = 0; i < data.length; i++) {
          const unitID = data[i][0];
          const date = data[i][1];
          const unitPrice = data[i][2];
          const request = { "unitID": unitID,
           "date": date, "unitPrice": unitPrice 
          };
          requests.push(request);
        };

          fetch('http://localhost:5001/api/fileupload', {
            method: 'POST',
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(requests)
          }).then(response=>{
            return new Promise((resolve, reject) => {
                if (response.ok) {
                    var contentType = response.headers.get("content-type");
                    if (contentType && contentType.includes("application/json")) {
                        response.json().then(json => resolve(json));
                    } else {
                        resolve();
                    }
                } else {
                    response.text().then(text => reject(text));
                }
            });
        })
      });
    };

    reader.readAsBinaryString(file);
  }
  render() {
    const { prices } = this.props;
    const fontSize = 5;

    return (
      <div align="center" >
        <br /><br /><br />
        <div className="dropzone">
          <Dropzone accept=".csv" onDropAccepted={this.onDrop.bind(this)}>            
          </Dropzone>
          <br /><br /><br />
        </div>
        <h2>Upload or drop your <font size={fontSize} color="#00A4FF">CSV</font><br /> file here.</h2>

        <table>
        <thead>
        <tr>
                <th>UnitID</th>
                <th>Date</th>
                <th>UnitPrice</th>
            </tr>
        </thead>
        <tbody>
        {prices.map((price, index) =>
        <tr key={price.id}>
        <td>{price.UnitID}</td>
        <td>{price.date}</td>
        <td>{price.unitPrice}</td>
        </tr>
        )}
        </tbody>
        </table>
      </div>
    )
  }
}

export default App;